
  MSRC4Plugin v1.2.2 - Win32 - 8/16/2006

  Copyright (C) 2003-2006 Sean E. Covel - All rights reserved

**********************************************************************

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
  USA.

  If the source code for the program is not available from the place from
  which you received this file, check
  http://home.comcast.net/~msrc4plugin

**********************************************************************

 The authors shall not in any way be liable for any damage or legal
 consequences as a result of using this software. We make absolutly no
 warranties about the reliability of this software. Use it at your own
 risks !
