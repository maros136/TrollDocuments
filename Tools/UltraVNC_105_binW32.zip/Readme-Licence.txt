This package contains UltraVNC addons that are FREE
but not necessarily OpenSource

- Ctrl-alt-del helper (for Vista)
- Video hook driver (aka Mirror Driver) (W2K, XP, VISTA)
- UltraScreenRecorder


Please read carrefully the following licences below:



 ************************************************************ 
 CAD.EXE
 ************************************************************

 ** TERMS AND CONDITIONS **

 This program is free
 
 Permission is granted by the UltraVNC Team to freely use this 
 program with the UltraVNC software


			    NO WARRANTY

  BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO 
  WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE 
  LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT 
  HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT
  WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT
  NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
  FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS TO THE 
  QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE 
  PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY 
  SERVICING, REPAIR OR CORRECTION.

  IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW WILL THE AUTHORS
  BE LIABLE TO YOU FOR DAMAGES,INCLUDING ANY GENERAL, SPECIAL, 
  INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR 
  INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS 
  OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY 
  YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH 
  ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN 
  ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

  ** END OF TERMS AND CONDITIONS **



  ** INTRODUCTION **

  Under Vista, Ctrl-Alt-Del can be simulated through the 
  Viewer only if UAC is enabled on the server (Vista) machine.
  The cad.exe file is used to simulate the ctrl-alt-del under Vista,
  but an alternate method is used by UltraVNC if this file is not 
  available






 ************************************************************ 
  UltraVNC Mirror Driver Licence
 ************************************************************



1. GRANT OF LICENSE:


RDV-Soft hereby grants Ultr@VNC Team -non-exclusive, royalty-free, worldwide, perpetual license to distribute, use the software product "Mirror driver" in binary form for their remote controle software. Ultr@VNC Team hereby grants the end-user the right to use and distribute the software product "Mirror Driver" with "Ultr@VNC".

 

2. LIMITED WARRANTY


NO WARRANTY. To the maximum extent permitted by applicable law, We expressly disclaims any warranty for the SOFTWARE PRODUCT "Mirror Driver". The SOFTWARE PRODUCT "Mirror Driver" and any related documentation are provided "as is" without warranty of any kind, either express or implied, including, without limitation, the implied warranties of merchantability or fitness for a particular purpose.
NO LIABILITY FOR CONSEQUENTIAL DAMAGES. To the maximum extent permitted by applicable law, in no event shall we be liable for any damages whatsoever (including, without limitation, damages for loss of business profit, business interruption, loss of business information, or any other pecuniary loss) arising out of the use of, or inability to use, this product.




 ************************************************************ 
  UltraScreen recorder Licence
 ************************************************************ 

Copyright (c) 2003, Rendersoft Camstudio
Copyright (c) 2007, UltraVNC Team

All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer. 
Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution. 
Neither the name of UltraVNC (Uvnc) nor the names of its contributors may
be used to endorse or promote products derived from this software without
specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.



UltraScreenRecorder is based on CamStudio source code (2002 version):


 ============================================
 RenderSoft CamStudio Licence (2002)
 ============================================


Unless otherwise specified, RenderSoft Software and Web Publishing owns all title to this software and its copyright, which are protected by international copyright law.

This product is FREEWARE and you are free to duplicate and distribute this software through the internet or any preferred media.

This product is OPENSOURCED and you are free to edit and modify its source code for your needs. The source code may be obtained from the product's website at : http://www.rendersoftware.com/products/camstudio

If you create an product that contains code derived from CamStudio, you are free to distribute it for any purposes, including commercial purposes. However, your product must include an acknowledgement that mention it contains code from RenderSoft CamStudio. A simple statement like "Part of this product is derived from RenderSoft CamStudio" in the AboutBox will do. You are not obliged to reveal the source code of your derived product but are encouraged to do so.
 

RenderSoft Software and Web Publishing specifically disclaims ALL warranties, express or implied, including but not limited to implied warranties of merchantability, fitness for a particular purpose, and non-infingement with respect to this software, its source code and any accompanying written materials.

IN NO EVENT will RenderSoft Software and Web Publishing be liable to you for damages, including any loss of profits, data, or other incidental or consequential damages arising out of your use or inability to use this software, even if RenderSoft Software and Web Publishing has been specifically advised on the possiblility of such damages.

By agreeing below, you indicate that you have read and understood the above licensing aggreement, and accept it as legally binding upon you.

If you choose not to accept any of the terms of this licensing agreement, please click the 'Exit' button now.


